So to run my application you need to download Microsoft Visual Studio
so firstly you visit the following Visual Studio free download
then you open the .exe file
then you start the installation and let it finish
then you choose the software version
then you select the desktop version
wait for the files to be downloaded then reboot your PC.
After rebooting it should be there.


So to use my application you declare the variable names in an array
then you create another array called myValue to hold the 7 variables.

then you ask the questions and for each question you save it under the subsequent array number with holds the values
for the variables stored under the array called expense.

from there you either select 1 to enter your monthly rental amount or 2 to enter the following values for a loan loan
if you enter any other number apart from 1 or 2 the system will display the "invalid number" output.

from there I created a class called Assignment an it extented to my Calcmonthlyrp() abstract class
which is the abstract class that I used to calculate the monthly Payment. Underneath the calculation 
is an if statement stating that if the monthly payment is greater than the monthly gross amount / 3
then the approval of the home loan is unlikely.

I created a abstract class called Expense to get and set the 7 variables
then I created another class called Homeloan which extended the expense class and I get and set the values
under Homeloan and I also put the Calcmonthlyrp() under both classes but the Calcmonthlyrp() calss under the 
Homeloan class will override whatever is under the Calcmonthlyrp() abstract class.