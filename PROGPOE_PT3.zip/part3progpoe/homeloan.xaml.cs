﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace part3progpoe
{
    /// <summary>
    /// Interaction logic for homeloan.xaml
    /// </summary>
    public partial class homeloan : Window
    {
        double tbl, tbr, monthlyHomeloanRepay, tgm, ttd, tir, moneyAvailable = 0;
       
        public homeloan()
        {
            InitializeComponent();
        }

        private void btnnext_Click(object sender, RoutedEventArgs e)
        {
          
            try
            {
                //Calculations for home loan
                double.TryParse(txtboxloanamount.Text, out tbl);
                double.TryParse(txtboxrepay.Text, out tbr);
                monthlyHomeloanRepay = (tbl / tbr) + tbl;
            }
            catch(Exception ex)
            {
                MessageBox.Show("An exception has occured while calculating your home loan: " + ex.Message);
                throw ex;
            }
            MessageBox.Show("The monthly home loan repayment for buying a property: " + monthlyHomeloanRepay);

            try
            {
               double.TryParse(txtboxinterestrate.Text, out tir);
               double.TryParse(txtboxtotaldeposit.Text, out ttd);
               double.TryParse(txtboxgrossmonthly.Text, out tgm);
               moneyAvailable = tgm - ttd + tir;
            }
            catch(Exception ex)
            {
                MessageBox.Show("Exception occured while calculating the available amount: " + ex.Message);
            }
            MessageBox.Show("The accessible monthly money after all the deductions have been made: " + moneyAvailable);

            if (tbr > 361 || tbr < 239)
            {
                MessageBox.Show("Invalid number!!!");
            }
            Calcmonthlyrp cmr = new Calcmonthlyrp();
            cmr.Show();
            this.Close();
        }

       
    }
}
