﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace part3progpoe
{
    /// <summary>
    /// Interaction logic for Calcmonthlyrp.xaml
    /// </summary>
    public partial class Calcmonthlyrp : Window
    {
        double monthlypayment, tla, tr, tn, tgm;
        public Calcmonthlyrp()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                double.TryParse(txtboxloanamount.Text, out tla);
                double.TryParse(txtboxrate.Text, out tr);
                double.TryParse(txtboxn.Text, out tn);
                monthlypayment = tla * (tr * Math.Pow(1 + tr, tn) / (Math.Pow(1 + tr, tn) - 1));
            }
            catch (Exception ex)
            {
                MessageBox.Show("Exception occured while calculating the monthly payment: " + ex.Message);
                throw ex;
            }

            double.TryParse(txtboxgrossmonthly.Text, out tgm);
            if(monthlypayment > tgm / 3)
            {
                MessageBox.Show("Approval of the home loan is unlikely.");
                MessageBox.Show($"Available money after payment: { tgm - monthlypayment}");
            }
            else
            {
                MessageBox.Show("Approval of home loan is likely.");
            }

            vehicle veh = new vehicle();
            veh.Show();
            this.Close();
        }
    }
}
