﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace part3progpoe
{
    /// <summary>
    /// Interaction logic for Savingsyes.xaml
    /// </summary>
    public partial class Savingsyes : Window
    {
        double tsa, tir, ty;

        private void btnfinish_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        public Savingsyes()
        {
            InitializeComponent();
        }

        private void btncalculate_Click(object sender, RoutedEventArgs e)
        {
            double.TryParse(txtboxsaveamount.Text, out tsa);
            double.TryParse(txtboxinterestrate.Text, out tir);
            double.TryParse(txtboxyears.Text, out ty);
            double save = (tsa * (tir / 12))/( Math.Pow(1 + (tir/12), 12 * ty)-1);

            MessageBox.Show("You need to save " + save);
        }
    }
}
