﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace part3progpoe
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Dictionary<string, double> expenses = new Dictionary<string, double>();

        double grossmonthlyinc;
        double grossmonthly;
        double estmonthlytaxdeduced;
        double groceries;
        double water;
        double lights;
        double travelcosts;
        double cellphones;
        double telephones;
        double otherexpenses;
        double selectnumber;
        double loanamount;
        double propertyprice;
        double totaldeposit;
        double interestrate;
        double repay;
        double monthlyhomeloanrepay;
        double moneyavailable = 0;
        double monthlypayment = 0;
        public static string setgroceries;
        public static string setwater;
        public static string settravelcosts;
        public static string setcellphones;
        public static string settelephones;
        public static string setotherexpenses;
        public static string setlights;
        double tg, tw, tl, ttc, tcp, ttp, toe;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnnext_Click(object sender, RoutedEventArgs e)
        {
            double.TryParse(txtboxgroceries.Text, out tg);
            double.TryParse(txtboxwater.Text, out tw);
            double.TryParse(txtboxlights.Text, out tl);
            double.TryParse(txtboxtravelcosts.Text, out ttc);
            double.TryParse(txtboxcellphones.Text, out tcp);
            double.TryParse(txtboxtelephones.Text, out ttp);
            double.TryParse(txtboxotherexpenses.Text, out toe);
            expenses.Add("Groceries: ", tg);
            expenses.Add("Water: ", tw);
            expenses.Add("Lights: ", tl);
            expenses.Add("Travelling: ", ttc);
            expenses.Add("Cell Phones: ", tcp);
            expenses.Add("Telephones: ", ttp);
            expenses.Add("Other: ", toe);

            MessageBox.Show("The expenses in descending order: ");
            MessageBox.Show(String.Join("\n", expenses.OrderByDescending(x => x.Value).Select(x => $"{x.Key}:{x.Value}")));



            property pt = new property();
            pt.Show();
            this.Close();

           
        }

       
    }
}
