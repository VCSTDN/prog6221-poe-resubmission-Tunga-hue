﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace part3progpoe
{
    /// <summary>
    /// Interaction logic for Vehicleinfo.xaml
    /// </summary>
    public partial class Vehicleinfo : Window
    {
        double tgm, temtd, tpp, tir, tip, ttd, tmm;
        public Vehicleinfo()
        {
            InitializeComponent();
        }

        private void btnnext_Click(object sender, RoutedEventArgs e)
        {
            double.TryParse(txtboxgrossmonthly.Text, out tgm);
            double.TryParse(txtboxestmonthlytaxDeduced.Text, out temtd);
            double income = tgm - temtd;

            double.TryParse(txtboxpurchaseprice.Text, out tpp);
            double.TryParse(txtboxcarinterestrate.Text, out tir);
            double.TryParse(txtboxestinsurancepremium.Text, out tip);
            double.TryParse(txtboxtotaldepo.Text, out ttd);
            double pricepermonth = tpp * tir / 100 / (5 * 12) + (5 * tip) + ttd;


            MessageBox.Show("The price of the car per month: " + pricepermonth);
            MessageBox.Show("Your income per months: " + income);

            if(pricepermonth > (income / 3 * 4))
            {
                MessageBox.Show(txtboxmodelmake.Text + "\n" + "This car is too expensive!!!");
            }

           

            Savings save = new Savings();
            save.Show();
            this.Close();

           
        }
    }
}
